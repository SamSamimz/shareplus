# About shareplus

This is a social media type application i made with laravel framework.
### Here are some of features :
- Custom authentication.
- User profile customization with image.
- I authenticated user can submit a post with image.
- User posts have the functionality of like & comment.
- In the post show page we can see those user profile who like the post.
