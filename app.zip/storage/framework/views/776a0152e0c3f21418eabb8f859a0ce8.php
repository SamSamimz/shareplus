<div>
    <div class="create_post row">
        <div class="d-flex align-items-center justify-content-center py-2">
            <button wire:click='openPostModal()' id="cooking_btn" class="btn">
              <div style="font-size: 60px">
                <i class="fas fa-plus"></i>
              </div>
                <div class="py-1">What's cooking into your life?</div>
            </button>
        </div>
    </div>


    
    <div>
      <div class="col-md-8 mx-auto">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-light p-3 mb-2 rounded">
              <div class="d-flex align-items-center justify-content-between">
                
                <div id="author-box" class="d-flex align-items-center gap-2">
                  <a href="<?php echo e(route('profile.show',$post->user->username)); ?>" wire:navigate>
                    <img class="author-image" src="<?php echo e($post->user->profile->image ? asset('storage/'.$post->user->profile->image) : asset('noimage1.jpg')); ?>" alt="">
                  </a>
                  <div>
                    <h6><a class="author-name" href="<?php echo e(route('profile.show',$post->user->username)); ?>" wire:navigate ><?php echo e($post->user->name); ?></a> <!--[if BLOCK]><![endif]--><?php if($post->feeling): ?>
                      <span class="feeling-text"><?php echo e($this->getFeeling($post->feeling)); ?></span>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]--> </h6>
                    <div class="text-secondary"><?php echo e($post->created_at->diffForHumans()); ?></div>
                  </div>
                </div>
                
                <div>
                  <div class="dropdown">
                    <button class="btn" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-vertical fa-lg"></i>
                    </button>
                    <ul class="dropdown-menu">
                      <li><a href="<?php echo e(route('post.show',[$post->user->username,$post->slug])); ?>" wire:navigate class="dropdown-item"><i class="fas fa-eye"></i> View Post</a></li>
                      <li wire:click='savePost(<?php echo e($post); ?>)'><a class="dropdown-item <?php echo e($this->saved($post) ? 'text-primary' : null); ?>"><i class="fas fa-bookmark"></i> <?php echo e($this->saved($post) ? 'Unsave' : 'Save Post'); ?></a></li>
                      <li onclick="copyLink(<?php echo e(json_encode(route('post.show',[$post->user->username,$post->slug]))); ?>)"><a class="dropdown-item"><i class="fas fa-code"></i> Copy Link</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <hr>
              
              <div id="post-box" class="p-3 rounded">
                <div class="pb-2"><?php echo e(Str::limit($post->caption,100)); ?></div>
                <div class="col-md-8 mx-auto">
                  <a href="<?php echo e(route('post.show',[$post->user->username,$post->slug])); ?>" wire:navigate>
                    <img class="post-image" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="">
                  </a>
                </div>
                <div class="d-flex align-items-center justify-content-around pt-2">
                  <span> <?php echo e($post->likes->count(). ' ' . Str::plural('like',$post->likes->count())); ?></span>
                  <span> <?php echo e($post->comments->count(). ' ' . Str::plural('comment',$post->comments->count())); ?></span>
                </div>
                <hr>
                
                <div class="d-flex align-items-center justify-content-around pt-2">
                    <i wire:click='likePost(<?php echo e($post); ?>)' class="fas fa-heart fa-lg <?php echo e($this->likedBy($post) ? 'text-primary' : null); ?>"></i>
                    <i class="fas fa-comment fa-lg"></i>
                </div>

              </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
      </div>
    </div>
    


  <!-- Modal -->
  <div wire:ignore.self class="modal fade" id="postModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="postModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="postModalLabel">Create a Post</h1>
          <button type="button" class="btn-close" wire:click='closePostModal()'></button>
        </div>
        <form wire:submit='addPost()'>
          <div class="modal-body">
            <div>
              <div class="mb-3">
                <label for="caption" class="form-label">Caption :</label>
                <textarea wire:model='caption' class="form-control" id="caption" cols="30" rows="2" placeholder="what's going into your mind."></textarea>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
              </div>
              <div class="mb-3">
                <label for="image" class="form-label">Add Image :</label>
                <input wire:model='image' type="file" class="form-control">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
              </div>
              <div class="mb-3">
                <label for="caption" class="form-label">Feeling :</label>
                <select wire:model='feeling' id="feeling" class="form-select">
                  <option value="" selected>Select how you feel now</option>
                  <option value="happy">Happy😀</option>
                  <option value="sad">Sad😥</option>
                  <option value="angry">Angry😡</option>
                  <option value="thankfull">Thankfull🙏</option>
                  <option value="blessed">Blessed😊</option>
                  <option value="excited">Excited😉</option>
                </select>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['feeling'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" wire:click='closePostModal()'>Close</button>
            <button type="submit" class="btn btn-primary">Add Post</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script>
        document.addEventListener('DOMContentLoaded', function() {
          Livewire.on('openPostModal',function() {  
            $('#postModal').modal('show');
          });
          Livewire.on('closePostModal',function() {  
            $('#postModal').modal('hide');
            $('.modal-backdrop').remove();
        });
    });
  </script>
  <script>
    function copyLink(link) {
        const textarea = document.createElement('textarea');
        textarea.value = link;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('Post link copied.' );
    }
  </script>
</div><?php /**PATH G:\Laravel11\shareplus\resources\views/livewire/posts/post-index.blade.php ENDPATH**/ ?>