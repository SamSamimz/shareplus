<div>
<div class="col-md-8 col-lg-6 mx-auto">
    <div class="bg-white px-3 py-2">
        <h2 class="py-3 text-center">Login Now!</h2>
        <!--[if BLOCK]><![endif]--><?php if(session()->has('invalid')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error! </strong> <?php echo e(session('invalid')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <form wire:submit.prevent='loginUser()'>
            <div class="mb-3">
                <label for="username" class="form-label">Username or Email</label>
                <input wire:model='username' type="text" id="username" class="form-control" placeholder="example@email">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input wire:model='password' type="password" id="password" class="form-control" placeholder="****">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="text-center">
                <button class="col-12 btn btn-warning text-white" type="submit">Login</button>
                <a class="" href="<?php echo e(route('register')); ?>" wire:navigate>Dons't have an account?</a>
            </div>
        </form>
    </div>
</div>

</div><?php /**PATH G:\Laravel11\shareplus\resources\views/livewire/auth/login.blade.php ENDPATH**/ ?>