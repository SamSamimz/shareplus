<div>
  <div class="pt-3">
    <div class="container">
      <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('posts.PostIndex');

$__html = app('livewire')->mount($__name, $__params, 'lw-336996689-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
  </div>
</div><?php /**PATH G:\Laravel11\shareplus\resources\views/livewire/home.blade.php ENDPATH**/ ?>