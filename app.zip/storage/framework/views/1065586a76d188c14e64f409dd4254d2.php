<div class="container">
    <div class="col-md-8 mx-auto">

        <div class="bg-light p-3 mb-2 rounded">
            <div class="d-flex align-items-center justify-content-between">
          
          <div id="author-box" class="d-flex align-items-center gap-2">
              <a href="<?php echo e(route('profile.show',$post->user->username)); ?>" wire:navigate>
              <img class="author-image" src="<?php echo e($post->user->profile->image ? asset('storage/'.$post->user->profile->image) : asset('noimage1.jpg')); ?>" alt="">
            </a>
            <div>
              <h6><a class="author-name" href="<?php echo e(route('profile.show',$post->user->username)); ?>" wire:navigate ><?php echo e($post->user->name); ?></a> <!--[if BLOCK]><![endif]--><?php if($post->feeling): ?>
                <span class="feeling-text"><?php echo e($this->getFeeling($post->feeling)); ?></span>
              <?php endif; ?><!--[if ENDBLOCK]><![endif]--> </h6>
              <div class="text-secondary"><?php echo e($post->created_at->diffForHumans()); ?></div>
            </div>
        </div>
        
        <div>
            <div class="dropdown">
              <button class="btn" data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="fas fa-ellipsis-vertical fa-lg"></i>
                </button>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('post.show',[$post->user->username,$post->slug])); ?>" wire:navigate class="dropdown-item"><i class="fas fa-eye"></i> View Post</a></li>
                    <li wire:click='savePost(<?php echo e($post); ?>)'><a class="dropdown-item <?php echo e($this->saved($post) ? 'text-primary' : null); ?>"><i class="fas fa-bookmark"></i> <?php echo e($this->saved($post) ? 'Unsave' : 'Save Post'); ?></a></li>
                    <li onclick="copyLink(<?php echo e(json_encode(route('post.show',[$post->user->username,$post->slug]))); ?>)"><a class="dropdown-item"><i class="fas fa-code"></i> Copy Link</a></li>
              </ul>
            </div>
          </div>
        </div>
        <hr>
        
        <div id="post-box" class="p-3 rounded">
            <div class="pb-2"><?php echo e(Str::limit($post->caption,100)); ?></div>
            <div class="col-md-8 mx-auto">
                <a href="<?php echo e(route('post.show',[$post->user->username,$post->slug])); ?>" wire:navigate>
                    <img class="post-image" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="">
                </a>
            </div>
          <div class="d-flex align-items-center justify-content-around pt-2">
              <span style="text-decoration: underline" wire:click='allLikers()'> <?php echo e($post->likes->count(). ' ' . Str::plural('like',$post->likes->count())); ?></span>
             
              <span> <?php echo e($post->comments->count(). ' ' . Str::plural('comment',$post->comments->count())); ?></span>
             
            </div>
          <hr>
          
          <div class="d-flex align-items-center justify-content-around pt-2">
              <i wire:click='likePost(<?php echo e($post); ?>)' class="fas fa-heart fa-lg <?php echo e($this->likedBy($post) ? 'text-primary' : null); ?>"></i>
              <i class="fas fa-comment fa-lg"></i>
          </div>
          
        </div>
    </div>


    <div class="bg-light p-3 mb-2 rounded">
        <h6 class="py-2">Leave a Comment :</h6>
        <!--[if BLOCK]><![endif]--><?php if($post->comments->count() == 0): ?>
            <div class="alert alert-warning">Be the first one who comment.</div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        
        <div>
            <form wire:submit.prevent='addComment(<?php echo e($post); ?>)'>
                <div class="mb-3">
                    <textarea wire:model='text' class="form-control" placeholder="Write your comment." cols="30" rows="2" autofocus></textarea>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                    <button type="submit" class="btn btn-primary">Post comment</button>
            </form>
        </div>
        
        <div class="pt-3">
            <h6 class="py-2">All Comments :</h6>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex align-items-center gap-2 mb-2">
              <div>
                <img class="comment-author-img"  src="<?php echo e($comment->user->profile->image ? asset('storage/'.$comment->user->profile->image) : asset('noimage1.jpg')); ?>" alt="">
              </div>
              <div class="d-flex align-items-center gap-4 bg-white rounded p-2">
                <div>
                  <a class="text-black fw-bold" href="<?php echo e(route('profile.show',$comment->user->username)); ?>" wire:navigate><?php echo e($comment->user->name); ?></a>
                  <div><?php echo e($comment->text); ?></div>
                </div>
                
                  <!--[if BLOCK]><![endif]--><?php if($this->postAuthor($post) || $this->commentAuthor($comment)): ?>
                  <div class="dropdown">
                    <button class="btn" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="fas fa-ellipsis-vertical"></i>
                    </button>
                    <ul class="dropdown-menu">
                      <!--[if BLOCK]><![endif]--><?php if($this->commentAuthor($comment)): ?>
                      <li><a class="dropdown-item">Edit</a></li>
                      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                      <li wire:click='deleteComment(<?php echo e($comment); ?>)'><a class="dropdown-item">Delete</a></li>
                    </ul>
                  </div>
                  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>


    
  <!-- Modal -->
  <div wire:ignore.self class="modal fade" id="modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="postModalLabel">People who likes</h1>
          <button type="button" class="btn-close" wire:click='closeModal()'></button>
        </div>
          <div class="modal-body max-h-300">
            <div class="bg-light rounded">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $post->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-2 d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center gap-2">
                        <img width="30" height="30" style="border-radius: 50%" src="<?php echo e($liker->user->profile->image ? asset('storage/'.$liker->user->profile->image) : asset('noimage1.jpg')); ?>">
                        <div class=""><?php echo e($liker->user->name); ?></div>
                    </div>
                    <div>
                        <a class="btn-transparent" href="<?php echo e(route('profile.show',$liker->user->username)); ?>" wire:navigate>View Profile</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" wire:click='closeModal()'>Close</button>
            <button type="submit" class="btn btn-primary">Add Post</button>
          </div>
      </div>
    </div>
  </div>


</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
      Livewire.on('openModal',function() {  
        $('#modal').modal('show');
      });
      Livewire.on('closeModal',function() {  
        $('#modal').modal('hide');
        $('.modal-backdrop').remove();
    });
});
</script>
</div><?php /**PATH G:\Laravel11\shareplus\resources\views/livewire/show-post.blade.php ENDPATH**/ ?>