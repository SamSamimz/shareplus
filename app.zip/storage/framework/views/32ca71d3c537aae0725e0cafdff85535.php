<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Share\Plus</title>
    <link rel="stylesheet" href="<?php echo e(asset('custom/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/bootstrap.min.css')); ?>">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.css')); ?>">
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body style="background-color: #f1efeff6">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('partials.navbar');

$__html = app('livewire')->mount($__name, $__params, 'lw-283115383-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <div class="pb-5"></div>
    <div class="pb-4"></div>
    <main><?php echo e($slot); ?></main>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <script src="<?php echo e(asset('bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('fontawesome/js/all.js')); ?>"></script>
</body>
</html><?php /**PATH G:\Laravel11\shareplus\resources\views/layouts/app.blade.php ENDPATH**/ ?>