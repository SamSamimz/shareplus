<div>
  <div class="pt-3">
    <div class="container">
      @livewire('posts.PostIndex')
    </div>
  </div>
</div>